@extends('layouts.app')

@section('content')
<div class="container mt-5">
    <h2>Add Product</h2>
    <form id="addProductForm" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="product_name">Product Name</label>
            <input type="text" class="form-control" id="product_name" name="product_name" required>
        </div>
        <div class="form-group">
            <label for="product_price">Product Price</label>
            <input type="number" class="form-control" id="product_price" name="product_price" step="0.01" required>
        </div>
        <div class="form-group">
            <label for="product_description">Product Description</label>
            <textarea class="form-control" id="product_description" name="product_description" rows="3" required></textarea>
        </div>
        <div class="form-group">
            <label for="product_images">Product Images</label>
            <input type="file" class="form-control-file" id="product_images" name="product_images[]" multiple required>
        </div>
        <button type="button" class="btn btn-primary" id="addProductButton">Add Product</button>
    </form>
</div>
<div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel" style="display: none;">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="successModalLabel">Success</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Product added successfully!
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {

        var addProductButton = document.getElementById('addProductButton');
        var successModal = document.getElementById('successModal');

        function showModal() {
            successModal.style.display = 'block';
        }

        function hideModal() {
            successModal.style.display = 'none';
        }

        addProductButton.addEventListener('click', function(event) {

            event.preventDefault();

            var formData = new FormData(document.getElementById('addProductForm'));

            fetch('{{ route("products.store") }}', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                console.log("first")
                console.log('Response:', data);
                showModal();
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });
    });
</script>

</script>
@endsection

@section('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>


@endsection
