

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Edit Product</h2>
    <form id="editProductForm" action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="form-group">
            <label for="product_name">Product Name</label>
            <input type="text" class="form-control" id="product_name" name="product_name" value="<?php echo e($product->product_name); ?>" required>
        </div>
        <div class="form-group">
            <label for="product_price">Product Price</label>
            <input type="number" class="form-control" id="product_price" name="product_price" step="0.01" value="<?php echo e($product->product_price); ?>" required>
        </div>
        <div class="form-group">
            <label for="product_description">Product Description</label>
            <textarea class="form-control" id="product_description" name="product_description" rows="3" required><?php echo e($product->product_description); ?></textarea>
        </div>
        <div class="form-group">
            <label for="product_images">Product Images</label>
            <input type="file" class="form-control-file" id="product_images" name="product_images[]" multiple>
            <div class="mt-3">
                <?php if($product->product_images): ?>
                    <?php $__currentLoopData = json_decode($product->product_images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('images/' . $image)); ?>" alt="Product Image" class="img-thumbnail" width="50">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
        <button type="button" id="updateProductButton" class="btn btn-primary">Update Product</button>
    </form>
</div>

<div class="modal fade" id="successModal"  style="display: none;">
    <div class="modal-body">
        Product updated successfully!
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var updateProductButton = document.getElementById('updateProductButton');
    updateProductButton.addEventListener('click', updateProduct);

    function updateProduct() {
        var formData = new FormData(document.getElementById('editProductForm'));

        fetch("<?php echo e(route('products.update', $product->id)); ?>", {
            method: 'POST',
            body: formData,
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json(); 
        })
        .then(data => {
            var successMessage = document.getElementById('successModal');
            successMessage.style.display = 'block';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again.');
        });
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel Projects\prod-management\resources\views/products/edit.blade.php ENDPATH**/ ?>